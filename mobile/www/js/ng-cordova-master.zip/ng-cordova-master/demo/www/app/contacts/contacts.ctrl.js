angular.module('demo.contacts.ctrl', [])

  .controller('ContactsCtrl', function ($scope, $log, $cordovaPreferences) {

  });
