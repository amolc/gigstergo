angular.module('demo.appAvailability.ctrl', [])

  .controller('appAvailabilityCtrl', function ($scope, $log, $cordovaPreferences) {

  });
